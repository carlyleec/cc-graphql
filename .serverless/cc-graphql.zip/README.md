# cc-graphql
A  Serverless GraphQL Backend for my resume/ portfolio site

## To play around with it
1. `git clone https://github.com/carlyleec/cc-graphql.git`
2. `yarn`
3. `npm start`

This will start a dev server running GraphiQL at [http://localhost:3000](http://localhost:3000/ggraphiql).

## To deploy

You'll need to set up your AWS credentials using Severless config
1. You need install Serverless, for instructions look [here](https://serverless.com/framework/docs/providers/aws/guide/installation/)
2. You'll also need to set up your AWS credentials for Severless using the Serveless CLI `config` command, instructions are [here](https://serverless.com/framework/docs/providers/aws/guide/credentials/)
3. Then run `serverless deploy` to deploy to the default AWS `us-east-1 `region with the default state of `dev`. To deploy to production or to a different AWS region use `serverless deploy --stage production --region us-west-1`. More on Serverless for AWS [here](https://serverless.com/framework/docs/providers/aws/guide/)
