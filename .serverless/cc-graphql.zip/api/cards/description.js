module.exports = 'A collection of cards';
