module.exports = 'A collection of jobs';
