module.exports = 'A place where I went to school';
