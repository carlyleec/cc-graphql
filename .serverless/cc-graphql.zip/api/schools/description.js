module.exports = 'A collection of schools I\'ve attended';
