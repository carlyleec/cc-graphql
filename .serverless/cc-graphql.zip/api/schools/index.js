const description = require('./description');
const type = require('./type');
const resolve = require('./resolve');

module.exports = {
  description,
  type,
  resolve,
};
