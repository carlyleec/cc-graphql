const schools = require('../../data/schools');

module.exports = () => (schools);
