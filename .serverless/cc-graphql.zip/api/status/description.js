module.exports = 'My current status';
