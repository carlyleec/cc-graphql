const status = require('../../data/status');

module.exports = () => (status);
