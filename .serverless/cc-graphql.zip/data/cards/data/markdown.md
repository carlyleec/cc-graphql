#Data plays a central role
In almost every project I've worked on, from databases to Geographic Information Systems (GIS) to the infrastructure that makes it all possible data is at the center.
