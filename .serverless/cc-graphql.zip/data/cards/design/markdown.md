I design full-stack web applications. Whether it’s an icon, an interface, a user experience, or a data structure, my aesthetic tends toward simplicity with a focus on usability.
