# Code is the heart and soul of what I do.
Mostly, I build things using modern JavaScript: from UIs to Servers to microservices. I do things in other languages too.
